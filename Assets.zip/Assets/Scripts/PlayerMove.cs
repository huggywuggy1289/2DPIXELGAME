using System;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public AudioClip audioJump;
    public AudioClip audioAttack;
    public AudioClip audioDamaged;
    public AudioClip audioItem;
    public AudioClip audioDie;
    public AudioClip audioFinish;
    public float maxSpeed;
    public float jumpPower;

    public Transform respawnPoint; // ��������� �����ϴ� Transform

    private Rigidbody2D rigid;
    private SpriteRenderer spriteRenderer;
    private Animator animator;
    private BoxCollider2D boxCollider;
    private AudioSource audioSource;

    private void Awake()
    {
        rigid = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
        boxCollider = GetComponent<BoxCollider2D>();
        audioSource = GetComponent<AudioSource>();

        // ���� ��ġ�� ������ �������� ����
        if (respawnPoint == null)
            respawnPoint = transform;
    }

    private void FixedUpdate()
    {
        //Move Speed
        float h = Input.GetAxisRaw("Horizontal");
        rigid.AddForce(Vector2.right * h * 3, ForceMode2D.Impulse);

        //Max Speed
        if (rigid.velocity.x > maxSpeed) // Right
        {
            rigid.velocity = new Vector2(maxSpeed, rigid.velocity.y);
        }
        else if (rigid.velocity.x < maxSpeed * (-1)) // Left
        {
            rigid.velocity = new Vector2(maxSpeed * (-1), rigid.velocity.y);
        }

        //Ray Collider Check
        if (rigid.velocity.y < 0) // ĳ���Ͱ� �ϰ� ���� ���� Raycast ����
        {
            Debug.DrawRay(rigid.position, Vector3.down * 1.0f, new Color(0, 1, 0));
            RaycastHit2D rayHit = Physics2D.Raycast(rigid.position, Vector3.down, 1.0f, LayerMask.GetMask("Platform"));
            if (rayHit.collider != null && rayHit.distance < 0.5f)
            {
                animator.SetBool("isJumping", false); // ���� ����
                Debug.Log("����: isJumping = false");
            }
        }

        // Check for falling off the platform
        if (transform.position.y < -10) // Ư�� Y�� ���Ϸ� ������ ���
        {
            Respawn();
        }
    }

    void Update()
    {
        // Jump
        if (Input.GetButtonDown("Jump") && !animator.GetBool("isJumping"))
        {
            rigid.AddForce(Vector2.up * jumpPower, ForceMode2D.Impulse);
            animator.SetBool("isJumping", true);
            PlaySound("JUMP");
        }

        // Stop Speed
        if (Input.GetButtonUp("Horizontal"))
        {
            rigid.velocity = new Vector2(rigid.velocity.normalized.x * 0.5f, rigid.velocity.y);
        }

        // Direction Sprite
        if (Input.GetButton("Horizontal"))
        {
            spriteRenderer.flipX = Input.GetAxisRaw("Horizontal") == -1;
        }

        // Animation
        if (Mathf.Abs(rigid.velocity.x) < 0.4)
        {
            animator.SetBool("isWalking", false);
        }
        else
        {
            animator.SetBool("isWalking", true);
        }
    }

    void PlaySound(string action)
    {
        switch (action)
        {
            case "JUMP":
                audioSource.clip = audioJump;
                break;
            case "ATTACK":
                audioSource.clip = audioAttack;
                break;
            case "DAMAGED":
                audioSource.clip = audioDamaged;
                break;
            case "ITEM":
                audioSource.clip = audioItem;
                break;
            case "DIE":
                audioSource.clip = audioDie;
                break;
            case "FINISH":
                audioSource.clip = audioFinish;
                break;
        }
        audioSource.Play();
    }

    void Respawn()
    {
        transform.position = respawnPoint.position; // �÷��̾� ��ġ�� ������ �������� �̵�
        rigid.velocity = Vector2.zero; // �ӵ��� �ʱ�ȭ�Ͽ� ���� ����
        rigid.angularVelocity = 0f; // ȸ�� �ӵ� �ʱ�ȭ (�ʿ��� ���)
        animator.SetBool("isJumping", false); // ���� ���� �ʱ�ȭ
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.contacts[0].normal.y > 0.7f) // ���� ��Ҵ��� Ȯ��
        {
            animator.SetBool("isJumping", false);
            Debug.Log("����: isJumping = false (Collision)");
        }
    }

}
